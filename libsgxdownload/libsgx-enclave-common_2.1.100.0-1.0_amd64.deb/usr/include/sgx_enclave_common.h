/*
 * Copyright (C) 2011-2018 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   * Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */



#ifndef _SGX_ENCLAVE_COMMON_H_
#define _SGX_ENCLAVE_COMMON_H_

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* The following macros are for GCC only */
# define OE_API
# define OE_IN
# define OE_IN_OPT
# define OE_OUT
# define OE_OUT_OPT

#define ENCLAVE_MK_ERROR(x)              (0x00000000|(x))

typedef enum
{
    ENCLAVE_ERROR_SUCCESS                   = ENCLAVE_MK_ERROR(0x0000),      /* No error. */
    ENCLAVE_NOT_SUPPORTED                   = ENCLAVE_MK_ERROR(0x0001),      /* Enclave type not supported, SGX not supported, or SGX device not present. */
    ENCLAVE_INVALID_SIGNATURE               = ENCLAVE_MK_ERROR(0x0002),      /* SGX – invalid Signature or SIGSTRUCT. */
    ENCLAVE_INVALID_ATTRIBUTE               = ENCLAVE_MK_ERROR(0x0003),      /* SGX – invalid SECS Attribute. */
    ENCLAVE_INVALID_MEASUREMENT             = ENCLAVE_MK_ERROR(0x0004),      /* SGX – invalid measurement. */
    ENCLAVE_NOT_AUTHORIZED                  = ENCLAVE_MK_ERROR(0x0005),      /* Enclave not authorized to run. */
    ENCLAVE_INVALID_ENCLAVE                 = ENCLAVE_MK_ERROR(0x0006),      /* Address is not a Valid Enclave. */
    ENCLAVE_LOST                            = ENCLAVE_MK_ERROR(0x0007),      /* SGX – enclave is lost (likely due to a power event). */
    ENCLAVE_INVALID_PARAMETER               = ENCLAVE_MK_ERROR(0x0008),      /* Invalid Parameter (unspecified) – may be due to type length/format. */
    ENCLAVE_OUT_OF_MEMORY                   = ENCLAVE_MK_ERROR(0x0009),
    ENCLAVE_DEVICE_NO_RESOURCES             = ENCLAVE_MK_ERROR(0x000a),      /* Out of EPC Memory. */
    ENCLAVE_ALREADY_INITIALIZED             = ENCLAVE_MK_ERROR(0x000b),      /* Enclave has already been initialized. */
    ENCLAVE_INVALID_ADDRESS                 = ENCLAVE_MK_ERROR(0x000c),      /* Address is not within a valid enclave./ Address has already been committed. */
    ENCLAVE_RETRY                           = ENCLAVE_MK_ERROR(0x000d),      /* Please retry the operation – there was an unmasked event in EINIT. */
    ENCLAVE_UNEXPECTED                      = ENCLAVE_MK_ERROR(0x1001),      /* Unexpected error. */
} enclave_error_t;

typedef enum
{
    ENCLAVE_TYPE_SGX1 = 1,      /* An enclave for the Intel Software Guard Extensions (SGX) architecture version 1. */
    ENCLAVE_TYPE_SGX2,          /* An enclave for the Intel Software Guard Extensions (SGX) architecture version 2. */
} enclave_type_t;

typedef enum
{
    ENCLAVE_PAGE_READ           = 1 << 0,      /* Enables read access to the committed region of pages. */
    ENCLAVE_PAGE_WRITE          = 1 << 1,      /* Enables write access to the committed region of pages. */
    ENCLAVE_PAGE_EXECUTE        = 1 << 2,      /* Enables execute access to the committed region of pages. */
    ENCLAVE_PAGE_THREAD_CONTROL = 1 << 8,      /* The page contains a thread control structure. */
    ENCLAVE_PAGE_UNVALIDATED    = 1 << 12,     /* The page contents that you supply are excluded from measurement and content validation. */
} enclave_page_properties_t;

#define SECS_SIZE 4096
#define SIGSTRUCT_SIZE 1808

typedef struct enclave_create_sgx_t {
    uint8_t secs[SECS_SIZE];
} enclave_create_sgx_t;

typedef struct enclave_init_sgx_t {
    uint8_t sigstruct[SIGSTRUCT_SIZE];
} enclave_init_sgx_t;

/* enclave_create()
 * Parameters:
 *      base_address [in, optional] - An optional preferred base address for the enclave.
 *      virtual_size [in] - The virtual address range of the enclave in bytes.
 *      initial_commit[in] - The amount of physical memory to reserve for the initial load of the enclave in bytes.
 *      type [in] - The architecture type of the enclave that you want to create.
 *      info [in] - A pointer to the architecture-specific information to use to create the enclave.
 *      info_size [in] - The length of the structure that the info parameter points to, in bytes.
 *      enclave_error [out, optional] - An optional pointer to a variable that receives an enclave error code.
 * Return Value:
 *      If the function succeeds, the return value is the base address of the created enclave.
 *      If the function fails, the return value is NULL. The extended error information will be in the enclave_error parameter if used.
*/
void* OE_API enclave_create(
  OE_IN_OPT  void*        base_address,
  OE_IN      size_t       virtual_size,
  OE_IN      size_t       initial_commit,
  OE_IN      uint32_t     type,
  OE_IN      const void*  info,
  OE_IN      size_t       info_size,
  OE_OUT_OPT uint32_t*    enclave_error 
);

/* enclave_load_data()
 * Parameters:
 *      target_address [in] - The address in the enclave where you want to load the data.
 *      target_size [in] - The size of the range that you want to load in the enclave, in bytes. 
 *      source_buffer [in, optional] - An optional pointer to the data you want to load into the enclave.
 *      data_properties [in] - The properties of the pages you want to add to the enclave.
 *      enclave_error [out, optional] - An optional pointer to a variable that receives an enclave error code.
 * Return Value:
 *      The return value is the number of bytes that was loaded into the enclave.
 *      If the number is different than target_size parameter an error occurred. The extended error information will be in the enclave_error parameter if used.
*/
size_t OE_API enclave_load_data(
  OE_IN      void*        target_address,
  OE_IN      size_t       target_size,
  OE_IN_OPT  const void*  source_buffer,
  OE_IN      uint32_t     data_properties,
  OE_OUT_OPT uint32_t*    enclave_error 
);

/* enclave_initialize()
 * Parameters:
 *      base_address [in] - The enclave base address as returned from the enclave_create API.
 *      info [in] - A pointer to the architecture-specific information to use to initialize the enclave. 
 *      info_size [in] - The length of the structure that the info parameter points to, in bytes.
 *      enclave_error [out, optional] - An optional pointer to a variable that receives an enclave error code.
 * Return Value:
 *      non-zero - The function succeeds.
 *      zero - The function fails and the extended error information will be in the enclave_error parameter if used.
*/
bool OE_API enclave_initialize(
  OE_IN      void*        base_address,
  OE_IN      const void*  info,
  OE_IN      size_t       info_size,
  OE_OUT_OPT uint32_t*    enclave_error 
);

/* enclave_delete()
 * Parameters:
 *      base_address [in] - The enclave base address as returned from the enclave_create API.
 *      enclave_error [out, optional] - An optional pointer to a variable that receives an enclave error code.
 * Return Value:
 *      non-zero - The function succeeds.
 *      zero - The function fails and the extended error information will be in the enclave_error parameter if used.
*/
bool OE_API enclave_delete(
  OE_IN      void*        base_address,
  OE_OUT_OPT uint32_t*    enclave_error 
);

#ifdef __cplusplus
}
#endif

#endif
