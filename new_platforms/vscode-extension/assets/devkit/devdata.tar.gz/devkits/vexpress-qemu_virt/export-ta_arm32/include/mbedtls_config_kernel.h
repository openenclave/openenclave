/* SPDX-License-Identifier: BSD-2-Clause */
/* Copyright (c) 2018, Linaro Limited */
#error "mbedTLS is not yet supported in kernel mode"
