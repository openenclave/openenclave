#include <bits/soundcard.h>
#include <bits/deprecations.h>
