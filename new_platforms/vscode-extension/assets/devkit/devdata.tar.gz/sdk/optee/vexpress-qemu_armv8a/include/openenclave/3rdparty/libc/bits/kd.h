#include <linux/kd.h>
#include <bits/deprecations.h>
