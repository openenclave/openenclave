#include <linux/vt.h>
#include <bits/deprecations.h>
