#undef __WORDSIZE
#define __WORDSIZE 64
#include <bits/deprecations.h>
