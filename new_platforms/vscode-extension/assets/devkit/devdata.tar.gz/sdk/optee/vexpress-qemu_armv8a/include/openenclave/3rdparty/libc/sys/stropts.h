#include <stropts.h>
#include <bits/deprecations.h>
