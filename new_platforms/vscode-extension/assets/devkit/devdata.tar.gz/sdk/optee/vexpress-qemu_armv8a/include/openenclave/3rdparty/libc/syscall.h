#include <sys/syscall.h>
#include <bits/deprecations.h>
