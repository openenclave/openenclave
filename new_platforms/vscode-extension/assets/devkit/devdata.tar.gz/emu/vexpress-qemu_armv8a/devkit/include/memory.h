/* SPDX-License-Identifier: BSD-2-Clause */
/*
 * Copyright (c) 2014, STMicroelectronics International N.V.
 */
#ifndef MEMORY_H
#define MEMORY_H
#include <string.h>

#endif /*MEMORY_H*/
